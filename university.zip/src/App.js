import React from 'react';
import CollegeTable from './CollegeTable';

function App() {
    return (
        <div className="App">
            <h1>College Details</h1>
            <CollegeTable />
        </div>
    );
}

export default App;
